import UIKit

struct FamousPainter
{
    let photoName: String
    let info: String
    let birthYear: Int
}

class ViewControllerC: UIViewController
{
    @IBOutlet weak var segmented: UISegmentedControl!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var pageControl: UIPageControl!
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet weak var introLabel: UILabel!
    
    let painters = [
        FamousPainter(photoName: "達利01", info: "達利，許多作品把具體的細節描寫和任意地誇張、變形、省略與象徵等手段結合地使用，創造一種超現實境界", birthYear: 1853),
        FamousPainter(photoName: "畢卡索01", info: "畢卡索，著名的藝術家、畫家、雕塑家、版畫家、作家。作品通常被分為四個時期，大致為「藍色時期」、「粉紅色時期」、「黑人時期」和「晚期」", birthYear: 1881),
        FamousPainter(photoName: "米羅01", info: "米羅，自小即對大自然的風景非常熱愛。喜愛繪畫女人、小鳥、太陽、星星等，並以自創符號及色塊構成，成為獨特的個人風格", birthYear: 1893)]
    
    //當前畫家的索引
    var index = 0
    
    //顯示初始的畫家資料
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let painter = painters[index]
        imageView.image = UIImage(named: painter.photoName) //設置圖片為畫家的照片
        introLabel.text = painter.info //設置標籤文字為畫家的介紹
    }
    
    @IBAction func nextPageControl(_ sender: UIPageControl)
    {
        index = sender.currentPage //更新index為頁面控制器的當前頁面

        let painter = painters[index]
        imageView.image = UIImage(named: painter.photoName) //設置圖片為畫家的照片
        introLabel.text = painter.info //設置標籤文字為畫家的介紹
        
        numberLabel.text = "\(index+1)/\(painters.count)" //設置顯示畫家索引的標籤文字
        segmented.selectedSegmentIndex = index //設置分段控制器選擇的索引位置
    }
    
    @IBAction func nextSegmented(_ sender: UISegmentedControl)
    {
        index = sender.selectedSegmentIndex //更新index為分段控制器選擇的索引位置

        let painter = painters[index]
        imageView.image = UIImage(named: painter.photoName) //設置圖片為畫家的照片
        introLabel.text = painter.info //設置標籤文字為畫家的介紹
        
        numberLabel.text = "\(index+1)/\(painters.count)" //設置顯示畫家索引的標籤文字
        pageControl.currentPage = index //設置頁面控制器的當前頁面
    }
    
    //回上一頁：連info按鈕」、「畫面向右滑」
    @IBAction func preButton(_ sender: Any)
    {   //index變量的值不可以小於零，為了避免這個錯誤，添加一些檢查確保index 變量的值在有效範圍內
        index = (index - 1 + painters.count) % painters.count //減少index的值，並透過取餘數達到循環效果

        let painter = painters[index]
        imageView.image = UIImage(named: painter.photoName) //設置圖片為畫家的照片
        introLabel.text = painter.info //設置標籤文字為畫家的介紹
        
        numberLabel.text = "\(index+1)/\(painters.count)" //設置顯示畫家索引的標籤文字
        segmented.selectedSegmentIndex = index //設置分段控制器選擇的索引位置
        pageControl.currentPage = index //設置頁面控制器的當前頁面
    }
    
    //到下一頁：連接「右鍵按鈕」、「畫面向左滑」
    @IBAction func nextButton(_ sender: Any)
    {
        index = (index + 1) % painters.count //增加index的值，並透過取餘數達到循環效果

        let painter = painters[index]
        imageView.image = UIImage(named: painter.photoName) //設置圖片為畫家的照片
        introLabel.text = painter.info //設置標籤文字為畫家的介紹
        
        numberLabel.text = "\(index+1)/\(painters.count)" //設置顯示畫家索引的標籤文字
        segmented.selectedSegmentIndex = index //設置分段控制器選擇的索引位置
        pageControl.currentPage = index //設置頁面控制器的當前頁面
    }
}
